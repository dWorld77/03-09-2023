<?php
    include 'database.php';

    // error_reporting(E_ERROR | E_PARSE);
    $con = $GLOBALS['db_conn'];    
    $auth_req = $_REQUEST["auth"];

    $student_name = "";
    $event_name = "";

    try 
    {
        $auth = AesCBC256_Decryption("1FXpxzQNpvoeZBMu5PXM", "$auth_req");
        if($auth !== null)
        {
            $auth = explode(":", $auth);
            $college_name = $auth[0];
            if($auth[2] !== "password")
            {
                DisplayErrorMessage("Invalid auth token !");
            }
            else
            {
                $query = "SELECT auth_status FROM token WHERE auth_token = '$auth_req'";

                $result = mysqli_query($con, $query);

                $countR = mysqli_num_rows($result);

                if (mysqli_num_rows($result) == 1) 
                {
                    $row = mysqli_fetch_assoc($result);
                
                    if($row["auth_status"] == "created" || $row["auth_status"] == "opened")
                    {
                        $query = "SELECT * FROM token WHERE auth_token = '$auth_req'";
                        $result = mysqli_query($con, $query);
                        $rowCount = mysqli_num_rows($result);

                        if (isset($_POST['register'])) 
                        {
                            $sResult = false;
                            $data = $_POST['data'];

                            if ($rowCount == 1)
                            { 
                                for($i =0; $i < count($data); $i++)
                                {
                                    $student_name = $data[$i];
                                    $event_name = $data[$i + 1];

                                    $query = "INSERT INTO registration (student_name, event_name, college_name, auth_token) VALUES ('$student_name', '$event_name', '$college_name', '$auth_req')";
                                   
                                    if (!mysqli_query($con, $query)) 
                                    {
                                       ErrorMessage($auth_req, "Error in inserting values");
                                    }
                                    else
                                    {
                                        $sResult = true;
                                    }
                                    
                                    $i += 1;
                                }
                                if(false)
                                {
                                    $query = "UPDATE token SET auth_status = 'closed' WHERE auth_token = '$auth_req'";
                                    if (!mysqli_query($con, $query)) 
                                    {
                                        ErrorMessage($auth_req, "Error in closing session");
                                    }
                                    else
                                    {
                                        header('Location: poster.php?id=' . hash('sha256', $auth_req));
                                        exit();
                                    }
                                }
                            }else
                            {
                                ErrorMessage($auth_req, "Auth Token is already exists !");
                            }

                           

                        
                        }
                        else
                        {
                            if ($rowCount == 1)
                            { 
                                $query = "SELECT auth_status FROM token WHERE auth_token = '$auth_req'";
                                $resultTR = mysqli_query($con, $query);
                                $countTR = mysqli_num_rows($result);
                
                                if (mysqli_num_rows($resultTR) == 1) 
                                {
                                    $rowTR = mysqli_fetch_assoc($resultTR);
                                    if($rowTR["auth_status"] == "created")
                                    {
                                        $query = "UPDATE token SET auth_status = 'opened' WHERE auth_token = '$auth_req'";
                                        if (!mysqli_query($con, $query)) 
                                        {
                                            ErrorMessage($auth_req, "Error in opening session");
                                        }
                                        // else
                                        // {   
                                        //     $file = dirname(dirname(getcwd())) . "\\php\\php.exe";
                                        //     $arg = getcwd()  . "\\tokenTimer.php" . " " . $auth_req;

                                        //     $WshShell = new COM("WScript.Shell");
                                        //     $oExec = $WshShell->Run($file . " " . $arg, 0);
                                        // }
                                    }
                                }
                                else
                                {
                                    DisplayErrorMessage("Auth token is expired or already exists !");
                                    exit();
                                }
                            }
                            else
                            {
                                ErrorMessage($auth_req, "Auth token is already exists !");
                            }
                        }
                    }
                    else
                    {
                        DisplayErrorMessage("Auth token is expired or already exists !");
                        exit();
                    }
                }
                else if(mysqli_num_rows($result) == 0)
                {
                    ErrorMessage($auth_req, "Error in creating session");
                }
                else
                {
                    ErrorMessage($auth_req, "Not sure what is going on !");
                    exit();
                }
            }
        }
        else
        {
            DisplayErrorMessage("Invalid auth token !");
        }

    }
    catch(Error $e)
    {
        ErrorMessage($auth_req, $e);
    }
   
    mysqli_close($con);

    function AesCBC256_Encryption($password, $content)
    {
        $method = 'aes-256-cbc';
        $key = substr(hash('sha256', $password, true), 0, 32);
        $iv = chr(0x7b) . chr(0x20) . chr(0x4b) . chr(0x72) . chr(0x79) . chr(0x70) . chr(0x74) . chr(0x65) . chr(0x78) . chr(0x5f) . chr(0x4f) . chr(0x5f) . chr(0x6f) . chr(0x20) . chr(0x7d) . chr(0x00);
        $encryptedContent = base64_encode(openssl_encrypt($content, $method, $key, OPENSSL_RAW_DATA, $iv));
        return $encryptedContent;
    }

    function AesCBC256_Decryption($password, $content)
    {
        $method = 'aes-256-cbc';
        $key = substr(hash('sha256', $password, true), 0, 32);
        $iv = chr(0x7b) . chr(0x20) . chr(0x4b) . chr(0x72) . chr(0x79) . chr(0x70) . chr(0x74) . chr(0x65) . chr(0x78) . chr(0x5f) . chr(0x4f) . chr(0x5f) . chr(0x6f) . chr(0x20) . chr(0x7d) . chr(0x00);
        $encryptedContent = openssl_decrypt(base64_decode($content), $method, $key, OPENSSL_RAW_DATA, $iv);
        return $encryptedContent;
    }

    function ErrorMessage($token, $error)
    {
        echo "<div class=\"Status\" style=\"color: red\"> Something Went Wrong Contact Admin's ! </div>";
        $value = "Token: " . $token . " | " . $error . "\n";
        file_put_contents('ErrorLogs.txt', $value,  FILE_APPEND | LOCK_EX);     
        exit();
    }

    function DisplayErrorMessage($message)
    {
        echo "<div class=\"Status\" style=\"color: red\">" . $message . "</div>";
        exit();
    }
?>
<!DOCTYPE html>
<html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<body>
    <div class="NavHeading">
        LOGO
     </div>
     <div class="SubHeading">
         <div class="s1">
             Registration form for
             <br>
             <span name="college"><?php echo $college_name; ?><span>
         </div>
     </div>
     <div class="mainContainer">
         <div class="container">
            <div class="form-group">
                <div class="NoteDiv">Please, Verify all details that you entered once again and submit registration.</div>
            </div>
            <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']) . "?auth=" . $auth_req; ?>" method="post">
                <div id="mainFormClass">
                     <div class="groupAlldiv">
                        <div class="RemoveButton">
                            X
                        </div>
                       
                        <div class="form-group">
                             <label style="font-weight: bold;">Name:</label>
                             <input type="text" name="data[]" placeholder="J James" required>
                        </div>
                        <div class="form-group">
                             <label style="font-weight: bold;">Event:</label>
                             <select name="data[]" required>
                                <option value="">Select an event</option>
                                <option value="Paper presentation">Paper presentation</option>
                                <option value="Software debugging">Software debugging</option>
                                <option value="Quiz - prelims & final">Quiz - prelims & final</option>
                                <option value="Digital poster making">Digital poster making</option>
                                <option value="Treasure hunt">Treasure hunt</option>
                                <option value="Facial painting">Facial painting</option>
                                <option value="Flameless cooking">Flameless cooking</option>
                             </select>
                         </div>
                     </div>
                 </div>
                 <div id="AddButton" class="AddButton">
                     Add
                 </div>
                
                 <div class="form-group">
                     <button type="submit" name="register" id="register" onclick="disableForm()">Register</button>
                 </div>
             </form>
         </div>
     </div>
    <script>
        const submitBtn = document.querySelector('button[type="submit"]');
        submitBtn.addEventListener('click', function(event) 
        {
            const confirmed = confirm('Are you sure you want to submit this form?');
            if (!confirmed)
            {
                event.preventDefault();
            }
        });

        const addFormBtn = document.getElementById('AddButton');
        const formsContainer = document.getElementById('mainFormClass');
        addFormBtn.addEventListener('click', function() 
        {
            const firstForm = document.querySelector('.groupAlldiv');
            const clonedForm = firstForm.cloneNode(true);
            formsContainer.appendChild(clonedForm);

            const inputs = clonedForm.querySelectorAll('input');
            inputs.forEach(function(input) 
            {
                input.value = '';
            });

            const allForm = document.querySelectorAll('.groupAlldiv');
            const lastForm = allForm[allForm.length - 1];
            const removeFormBtns = document.querySelectorAll('.RemoveButton');
            removeFormBtns.forEach(function(btn) 
            {
                btn.style.display = 'inline-block';
                btn.addEventListener('click', function() 
                {
                    if (document.querySelectorAll('.groupAlldiv').length > 1) 
                    {
                        const formGroup = btn.closest('.groupAlldiv');
                        formGroup.remove();
                        if (document.querySelectorAll('.groupAlldiv').length === 1) 
                        {
                            const lastFormRemoveBtn = document.querySelector('.groupAlldiv .RemoveButton');
                            lastFormRemoveBtn.style.display = 'none';
                        }
                    }
                });
            });

            if (allForm.length > 1) 
            {
                const firstFormRemoveBtn = document.querySelector('.groupAlldiv .RemoveButton');
                firstFormRemoveBtn.style.display = 'block';
            }
        });
        const removeFormBtns = document.querySelectorAll('.RemoveButton');
        removeFormBtns[removeFormBtns.length - 1].style.display = 'none';
        
      

      </script>
</body>
</html>