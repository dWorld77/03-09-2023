<?php
    $tokenHashed = $_REQUEST["id"];
    echo $tokenHashed;

    // try to add poster 
?>